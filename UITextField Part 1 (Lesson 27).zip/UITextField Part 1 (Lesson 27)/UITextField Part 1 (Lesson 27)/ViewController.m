//
//  ViewController.m
//  UITextField Part 1 (Lesson 27)
//
//  Created by Anton Gorlov on 29.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   // self.firstNameField.keyboardAppearance = UIKeyboardAppearanceDark; //темная клава
   //  self.lastNameField.keyboardAppearance = UIKeyboardAppearanceLight;  //светлая клава
    
    
   // То,что мы сделали (DELEGATE)автоматически не делает нас (DELEGATE) наших классов (сделаем вручную)
    
   // self.firstNameField.delegate = self; //можно поставить через storyBoard (смотри тетрадь Урок 27)
   // self.lastNameField.delegate = self;
    
    //как только загружаем ViewController,то сразу выезжает клава
    
    [self.firstNameField becomeFirstResponder];
    
    //работа с Notification (3 шт)
    
    UIKIT_EXTERN NSString *const UITextFieldTextDidBeginEditingNotification;
    UIKIT_EXTERN NSString *const UITextFieldTextDidEndEditingNotification;
    UIKIT_EXTERN NSString *const UITextFieldTextDidChangeNotification;
    
    NSNotificationCenter * nc = [NSNotificationCenter defaultCenter];
    
    [nc addObserver:self
               selector:@selector(notificationTestDidBeginEditing:)
               name:UITextFieldTextDidBeginEditingNotification
               object:nil];
    
    [nc addObserver:self
           selector:@selector(notificationTestDidEditing:)
               name:UITextFieldTextDidEndEditingNotification
             object:nil];
    
    [nc addObserver:self
           selector:@selector(notificationTestDidChangeEditing:)
               name:UITextFieldTextDidChangeNotification
             object:nil];



}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark- Action

- (IBAction)actionLog:(id)sender {
    
    NSLog(@"first name = %@, last name = %@",self.firstNameField.text, self.lastNameField.text);
    
    if ([self.firstNameField isFirstResponder]) { // есть ли фокус на нашем элементе
        [self.firstNameField resignFirstResponder]; //если есть на нем фокус,то убираем клаву
        
    } else if ([self.lastNameField isFirstResponder]) {
        [self.lastNameField resignFirstResponder];
    
    }
    
   
}

- (IBAction)actionTextChanged:(UITextField *)sender {
    NSLog(@"%@",sender.text);
}

#pragma mark- UITextFieldDelegate


- (BOOL)textFieldShouldClear:(UITextField *)textField { //метод,который требует от нас возвратить BOOL значение.Передает TextField и спрашивает можно очистить? (DELEGATE)

    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField { // спрашивает можно сделать Return?(какую-то предпринять  операцию,когда нажали на эту кнопку.(Return,Next,Go) (DELEGATE)
 
    if ([textField isEqual:self.firstNameField]) {
        
        [self.lastNameField becomeFirstResponder]; //это тот обьект на котором есть фокус (курсор активен (горит).После ввода поля "firstName" курсор (фокус прыгнет на поле "lastName" ))
        
    }else {
        
        [textField resignFirstResponder]; //убираем его от "FirstResponder" (набрали, нажали "Return" и клава уехала )
    }
  
   
  
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField { //делает так,что "firstName" можно редактировать ,а "lastname" - нет.
   // return [textField isEqual:self.firstNameField]; //возвращает textField на который нажали (если это firstNameField - можно редактировать,если нет - нельзя редактировать).
    return YES;
    
}

#pragma mark- Notification
//Подписали на 3 нотификации - теперь реализуем их

- (void) notificationTestDidBeginEditing:(NSNotification*) notification {
    
    NSLog(@"notificationTestDidBeginEditing");

}

- (void) notificationTestDidEditing:(NSNotification*) notification {
    
    NSLog(@"notificationTestDidEditing");

}

- (void) notificationTestDidChangeEditing:(NSNotification*) notification {
    
    NSLog(@"notificationTestDidChangeEditing");
    
}


- (void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}
@end
