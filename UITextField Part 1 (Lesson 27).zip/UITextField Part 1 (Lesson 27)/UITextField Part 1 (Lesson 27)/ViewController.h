//
//  ViewController.h
//  UITextField Part 1 (Lesson 27)
//
//  Created by Anton Gorlov on 29.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *firstNameField;
@property (weak, nonatomic) IBOutlet UITextField *lastNameField;
@property (weak, nonatomic) IBOutlet UIButton *actionButton;

- (IBAction)actionLog:(id)sender;
- (IBAction)actionTextChanged:(UITextField *)sender;

@end

