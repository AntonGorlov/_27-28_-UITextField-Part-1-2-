//
//  AppDelegate.h
//  UITextField Part 2 (Lesson 28)
//
//  Created by Anton Gorlov on 03.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

