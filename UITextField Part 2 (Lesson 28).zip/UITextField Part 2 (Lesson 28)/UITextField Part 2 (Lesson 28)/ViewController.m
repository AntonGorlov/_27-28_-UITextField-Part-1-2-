//
//  ViewController.m
//  UITextField Part 2 (Lesson 28)
//
//  Created by Anton Gorlov on 03.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

   
    self.view.layer.contents = (id)[UIImage imageNamed:@"TestView for Leson 28.jpg"].CGImage; //ставим картинку на background
   //как только загружается наше приложение,то вызываем клаву
        [self.firstNameField becomeFirstResponder];
    
}

#pragma mark - UITextFieldDelegate



- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string { //этот метод вызываеться ,когда добавляем в textField новую букву.Тут же приходит вопрос "должны мы изменить буквы в range (диапазон,ряд) на эту строку string (то что вводили) ???" replacementString - это новая строка (введенная только что)
    
    
   // NSLog(@"textField = %@",textField.text); //выводим текст
  //  NSLog(@"shouldChangeCharactersInRange = %@", NSStringFromRange(range));
    NSLog(@"replacementString = %@",string); //выводим нашу строку

    //Запретим ввод всякой ерунды,кроме "decimalChSet".Разделим входящюю строку на компоненты и посмотрим их кол-во,если не то,которое нам нужно (не допускаем!!)
    
    NSCharacterSet* validationSet = [[NSCharacterSet decimalDigitCharacterSet]invertedSet]; //инвертируем
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validationSet];
    
    if ([components count]>1) { //считаем,если компонентов больше одного (если строка пустая это "0") Если разделяет цифры,то не допускаем (цифра -это "1" компонент).
        return NO; //- все ,что не цифры не допускаем
    }
    
    // соз ту строку,которую хотим выводить и ограничим ее длину
    
    NSString* newString = [textField.text stringByReplacingCharactersInRange:range withString:string]; //берем строку,которая находится в "textField" и просто replacing (замена)
    
   //+XX (XXX) XXX-XXXX
    
    NSLog(@"newString = %@",newString);
    
     NSArray* validComponents = [newString componentsSeparatedByCharactersInSet:validationSet];
    
    
    newString = [validComponents componentsJoinedByString:@""];//соединяем массив пустым символом,чтобы получить строку (XXXXXXXXXX)
    //XXXXXXXXXX
    
    NSLog(@"new string fixed  %@", newString);
    
    static const int localNumberMaxLength = 7; //"static" - будет инициализирована один раз внутри функции (как будем заходит,она уже будет существовать)
    
    static const int areaCodeMaxLength = 3; //"const" - переменная не может менятся (нельзя записать др. значение)
    
    static const int countryCodeMaxLength = 3;

    //проверим длину
    
    if ([newString length] > localNumberMaxLength + areaCodeMaxLength + countryCodeMaxLength) {
        return NO;
    }
    
     NSMutableString* resultString = [NSMutableString string]; // когда надо клепать строки (собирать,разделять),то используем "NSMutableString"
    
    
  // NSArray* words = [newString componentsSeparatedByString:@" "]; //Узнаем ,сколько слов разделено пробелом (колво компонентов)
    
  //  NSLog(@"words = %@",words); //пишем любые цифры и жмем пробел и он разделяет (пробелом) на компоненты нашу строку
    
    //Сделаем свой собственный сет,чтобы разделить любыми символами на компоненты.
    //NSCharacterSet - это набор элементов.

    
    /*
     XXXXXXXXXX
     +XX (XXX) XXX-XXXX
     
    */
    
    //Определим длину ,если ввел 10,то нужно брать только 7!!!
    
    NSInteger localNumberLength = MIN([newString length], localNumberMaxLength); //делаем MIN значение (либо 7 символов либо меньше )
    
    
    if (localNumberLength  > 0) {
        
        //узнаем номер
        NSString* number = [newString substringFromIndex:(int)[newString length] - localNumberLength]; //берем кол-во наше и отсчитываем от конца
        
        [resultString appendString:number]; //добавим в наш рузультат
    }
    //проверим
    
    if ([resultString length] > 3) {
        
        [resultString insertString:@"-" atIndex:3]; // если больше 3-х символов,то ставим "-",почему "3"??? так как начинается с "0"
    }
    
    if ([newString length] > localNumberLength) { //если строка больше 7,тогда есть areaCodeNumberMaxLength
        
        NSInteger areaCodeLenght = MIN((int)[newString length] -localNumberMaxLength , areaCodeMaxLength); //вычислим длину
        
        NSRange areaRange = NSMakeRange((int)[newString length] - localNumberMaxLength - areaCodeLenght, areaCodeLenght);// определим индекс откуда начинаем запиливать
        //соз area строку
        
        NSString* area = [newString substringWithRange:areaRange]; //вырезаем
        
        area = [NSString stringWithFormat:@"(%@) ",area];
        
        [resultString insertString:area atIndex:0];
       
        
        
    }
    
    textField.text = resultString;//сформировали строку,если мы сформировали,то вставляем в "textField"(скажем нельзя тебе менять,но мы туда впишем)

    
    return NO;
    

}


/*
 
 //   NSCharacterSet* set = [NSCharacterSet characterSetWithCharactersInString:@" ,="];//соз сет на основе символов этой строки (пробел (запятая) и ?)
 
 NSCharacterSet* set = [[NSCharacterSet decimalDigitCharacterSet]invertedSet]; //default set (decimalChSet) /invertedSet - все остальне Character кроме decimalDigitCharacterSet (все,что не являеться цифрой будет разделять на слова)
 
 NSArray* words = [resultString componentsSeparatedByCharactersInSet:set]; // компоненты разделенные символами в сете
 NSLog(@"words = %@",words);
 */



// return [newString length] <= 10;//ограничение ввода (до 10 знаков).









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
