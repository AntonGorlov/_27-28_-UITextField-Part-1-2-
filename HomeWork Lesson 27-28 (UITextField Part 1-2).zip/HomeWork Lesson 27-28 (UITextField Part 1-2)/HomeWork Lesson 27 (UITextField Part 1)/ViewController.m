//
//  ViewController.m
//  HomeWork Lesson 27 (UITextField Part 1)
//
//  Created by Anton Gorlov on 29.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
typedef enum {
    
    AGFieldsName,
    AGFieldsLastName,
    AGFieldsLogin,
    AGFieldsPswd,
    AGFieldsAge,
    AGFieldsPhone,
    AGFieldsEmail,
    
    
} AGFields; // поля

@interface ViewController () <UITextFieldDelegate>

@end

@implementation ViewController

/*
                                                         Урок 27-28 !!!
 
 
 Создаем форму для регистрации студента.
 
 Ученик.
 
 1. Создайте поля (и лейблы напротив как в уроке): имя, фамилия, логин, пароль, возраст, телефон, имеил адрес.
 2. Установите правильные виды клавиатур для каждого текстового поля.
 3. У всех текстовых полей кроме последнего кнопка ретерн должна быть NEXT, а у последнего DONE.
 4. Осуществите переход по кнопкам NEXT и уберите клаву с экрана кнопкой DONE.
 5. Каждое поле при нажатии должно иметь кнопку очистки
 
 
 Студент
 
 6. Совет, чтобы осуществить переход по NEXT без проверки тонны пропертей, попробуйте использовать UIOutletCollection
 7. Создайте соответствующие каждому текстовому полю UILabel чтобы выводить туда информацию из текстовых полей. Сделайте их мелкими и другого цвета.
 8. По изменению текста (даже буквы) обновляйте эти лейблы (не забудте про CLEAR button)
 
 
 Мастер
 
 9. Для поля ввода телефона используйте мой код из видео, можете поместить его в какой-то оотдельный метод если надо
 10. Этот код должен работать только для поля телефона и не для какого другого
 
 Супермен
 
 11. Для поля ввода имеила ограничте ввод символов недопустимых в адресе
 12. Более того, сибвол "@" может быть введен только 1 раз
 13. установите разумное ограничение для этого поля
 
*/
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.firstNameField becomeFirstResponder]; // появление клавы в первом рег-нном поле.
    
   //delegate 1-й способ, 2-й способ (через storyBoard) в тетради 27 Урок!
    /*
    self.firstNameField.delegate = self;
    self.lastNameField.delegate = self;
    self.loginField.delegate = self;
    self.passwordField.delegate = self;
    self.ageField.delegate = self;
    self.numberField.delegate = self;
    self.eMailField.delegate = self;
    */
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//Уровень "Ученик"

#pragma mark- UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    //1-й способ
    
    for (int i = 0; i < ([self.textCollectionField count]-1); i++) { // при нажатии кнопки "Return" курсор идет в след. поле.
        
        if (!([ textField isEqual:[self.textCollectionField objectAtIndex:i]])) {
            
            [textField resignFirstResponder]; // убираем клаву
            
        }else {
            
            [[self.textCollectionField objectAtIndex:i+1] becomeFirstResponder];
        }
    }
   
  /* 2-й способ
    if ([textField isEqual:self.firstNameField]) { // при нажатии кнопки "Return" курсор идет в след. поле.
        
        [self.lastNameField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.lastNameField]) {
        
        [self.loginField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.loginField]) {
        
        [self.passwordField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.passwordField]) {
        
        [self.ageField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.ageField]) {
        
        [self.numberField becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.numberField]) {
        
        [self.eMailField becomeFirstResponder];
        
    }else {
        [self.eMailField resignFirstResponder]; // убираем клаву
    
    }
    */
    
    
    return YES;

}

- (BOOL)textFieldShouldClear:(UITextField *)textField  { // при очистке поля (textField) удаляеться и label.
    
    for (UILabel* label in self.labelCollectionField) {
        if (textField.tag == label.tag) {
            label.text = nil;
        }
    
    }
    return YES;



}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string { // изменяет символы в диапазоне
    
    NSString* resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    //метод заменяет символы в диапазоне с заданной строки, возвращая новую строку.
    
    switch (textField.tag) {
        case AGFieldsName:
            self.nameLabel.text = resultString;
            break;
            
        case AGFieldsLastName:
            self.surnameLabel.text = resultString;
            break;
            
        case AGFieldsLogin:
            self.loginLabel.text = resultString;
            break;
            
        case AGFieldsPswd:
            self.passwordLabel.text = resultString;
            break;
            
        case AGFieldsAge:
            
            [self scriptAgeField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.ageLabel.text = resultString;
            
            return NO;
            break;
            
        case AGFieldsPhone:
            
            [self scriptPhoneField:textField shouldChangeCharactersInRange:range replacementString:string ];
            self.phoneLabel.text = resultString;
           
            return NO;
            break;
            
        case AGFieldsEmail:
            
            [self scriptEmailField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.emailLabel.text = resultString;
            
            return NO;
            break;
            
            
        default:
            break;
    }
    
    
    
    return YES;


}


#pragma mark-Methods

- (BOOL)scriptPhoneField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    
    NSCharacterSet* validationSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSArray* components = [string componentsSeparatedByCharactersInSet:validationSet];
    
    if ([components count] > 1) {
        return NO;
    }
    
    NSString* newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    //+XX (XXX) XXX-XXXX
    
    NSLog(@"new string = %@", newString);
    
    NSArray* validComponents = [newString componentsSeparatedByCharactersInSet:validationSet];
    
    newString = [validComponents componentsJoinedByString:@""];
    
    // XXXXXXXXXXXX
    
    NSLog(@"new string fixed = %@", newString);
    
    static const int localNumberMaxLength = 7;
    static const int areaCodeMaxLength = 3;
    static const int countryCodeMaxLength = 3;
    
    if ([newString length] > localNumberMaxLength + areaCodeMaxLength + countryCodeMaxLength) {
        return NO;
    }
    
    
    NSMutableString* resultString = [NSMutableString string];
    
    /*
     XXXXXXXXXXXX
     +XX (XXX) XXX-XXXX - local number
     */
    
    NSInteger localNumberLength = MIN([newString length], localNumberMaxLength);
    
    if (localNumberLength > 0) {
        
        NSString* number = [newString substringFromIndex:(int)[newString length] - localNumberLength];
        
        [resultString appendString:number];
        
        if ([resultString length] > 3) {
            [resultString insertString:@"-" atIndex:3];
        }
        
    }
    
    if ([newString length] > localNumberMaxLength) {
        
        NSInteger areaCodeLength = MIN((int)[newString length] - localNumberMaxLength, areaCodeMaxLength);
        
        NSRange areaRange = NSMakeRange((int)[newString length] - localNumberMaxLength - areaCodeLength, areaCodeLength);
        
        NSString* area = [newString substringWithRange:areaRange];
        
        area = [NSString stringWithFormat:@"(%@) ", area];
        
        [resultString insertString:area atIndex:0];
    }
    
    if ([newString length] > localNumberMaxLength + areaCodeMaxLength) {
        
        NSInteger countryCodeLength = MIN((int)[newString length] - localNumberMaxLength - areaCodeMaxLength, countryCodeMaxLength);
        
        NSRange countryCodeRange = NSMakeRange(0, countryCodeLength);
        
        NSString* countryCode = [newString substringWithRange:countryCodeRange];
        
        countryCode = [NSString stringWithFormat:@"+%@ ", countryCode];
        
        [resultString insertString:countryCode atIndex:0];
    }
    
    
    textField.text = resultString;
    
    return NO;
    

}

- (BOOL) scriptEmailField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
//соз набор символов
    NSCharacterSet* validation = [NSCharacterSet characterSetWithCharactersInString:@"!#$%^?&,<>""''()+-:;{}[]|/*//\\ "];
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validation];
    
    if ([components count] > 1) {
        return NO;
    }
    
     NSString* emailResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    if (([emailResultString rangeOfString:@"@"].length < 1)) {
        
        self.atPresent = NO;
    }
    
    if ([emailResultString length] <2 && [string isEqualToString:@"@"]) { //Если должны выполняться два и более условия, используется логический оператор И, представляемый двумя сиволами амперсанда &&.
        
        return NO;
        
    }
    
    if (self.atPresent && [string isEqualToString:@"@"]) {
        return NO;
    }
   
    if ([string isEqualToString:@"@"]) {
        self.atPresent = YES;
    }
    
    
    textField.text = emailResultString;
    
    return NO;


}

- (BOOL) scriptAgeField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSCharacterSet* validation = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validation];
    
    if ([components count] > 1) {
        return NO;
    }
    NSString *resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([resultString intValue] < 18) {
        
        textField.text = resultString;
        
        return NO;
        
    }else if ([resultString intValue] > 120){
        
        return NO;
    
    }else {
     textField.text = resultString;
    
    }
    
    
    return NO;
}



@end
